﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Project2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        double standard_work_week = 40.00;
        double over_time = 0.00;
        double pay = 0.00;

        public MainPage()
        {
            this.InitializeComponent();
        }

        private double Calculate(double hours_worked, double pay_per_hour)
        {
            pay = hours_worked * pay_per_hour;
            if (hours_worked > standard_work_week)
            {
                over_time = double.Parse(HoursWorked.Text) - standard_work_week;
                pay = (standard_work_week + over_time * 1.5) * pay_per_hour;
            }
            return pay;
     
        }

        private void calculateClick(object sender, RoutedEventArgs e)
        {
            try
            {
                Results.Text = "";
                double age = double.Parse(AgeBox.Text);
                double pay_per_hour = double.Parse(HRateBox.Text);
                double hours_worked;
                if (HoursWorked.Text.Equals(""))
                {
                    hours_worked = standard_work_week;
                }
                else
                {
                    hours_worked = double.Parse(HoursWorked.Text);
                }
                
                if (pay_per_hour > 0 && hours_worked > 0 && age > 0)
                {

                    double pay = Calculate(hours_worked, pay_per_hour);
                    string formatted_pay = pay.ToString("#,##0.##");
                    string formatted_age = age.ToString("###");
                    String result_string = $"Full Name: {FirstNameBox.Text} {LastNameBox.Text} " +
                        $"\nAge: {formatted_age} " +
                        $"\nWeekly Pay: ${formatted_pay}";
                    Results.Text = result_string;
                }
                else
                {
                    Results.Text = "Please choose a value greater than 0!";
                }
            }
            catch (Exception caught)
            {
                Results.Text = "";
                Results.Text = "The input data was not in the \ncorrect format. Please try again."; 
            }
        }
    }
}
