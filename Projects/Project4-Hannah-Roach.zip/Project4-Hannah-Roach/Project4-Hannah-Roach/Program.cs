﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Hannah_Roach
{
    class Program
    {

        static void doWork()
        {
            var suppliers = new[] {
                new {SN = 1, SName = "Smith", Status = 20, City = "London"},
                new {SN = 2, SName = "Jones", Status = 10, City = "Paris" },
                new {SN = 3, SName = "Blake", Status = 30, City = "Paris" }
            };
            var parts = new[] {
             new {PN = 1, PName = "Nut", Color = "Red", Weight = 12, City = "London"},
            new {PN = 2, PName = "Bolt", Color = "Green", Weight = 17, City = "Paris"},
            new {PN = 3, PName = "Screw", Color = "Blue", Weight = 17, City = "Rome"}
            };
            var shipment = new[] {
                new {SN = 1, PN = 1, Qty = 300},
                new {SN = 1, PN = 2, Qty = 200},
                new {SN = 1, PN = 3, Qty = 400},
                new {SN = 1, PN = 4, Qty = 200},
                new {SN = 1, PN = 5, Qty =100},
                new {SN = 1, PN = 6, Qty = 100},
                new {SN = 2, PN = 1, Qty = 300},
                new {SN = 2, PN = 2, Qty = 400},
                new {SN = 3, PN = 2, Qty =200}
            };

            //1.Display the content of each of the arrays: suppliers, parts, and shipment.
            Console.WriteLine("\nComplete list: Shipments\n");
            var shipmt = shipment.Select(s => s);
            foreach (var s in shipmt)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine("\nComplete list: Parts\n");
            var pts = parts.Select(p => p);
            foreach (var p in pts)
            {
                Console.WriteLine(p);
            }

            Console.WriteLine("\nComplete list: Supplier\n");
            var sup = suppliers.Select(s => s);
            foreach (var s in sup)
            {
                Console.WriteLine(s);
            }

            //2. Prompt user for a Color input, and use 
            // that color to Query and display all cities that a part with such a color 
            // is located in (show each city name once).

            Console.WriteLine("\n Please enter a color: ");
            string Clr = Console.ReadLine();

            var city_with_color = parts.Where(p => p.Color.ToLower() == Clr).Select(p => p.City).Distinct();
            foreach (var c in city_with_color)
            {
                Console.WriteLine(c);
            }

            //3. Query suppliers data and display only the suppliers names in ascending order.
            Console.WriteLine("\n Supplier names in ascending order");
            var supplier_list_aes = suppliers.OrderBy(s => s.SName).Select(s => s.SName);
            foreach (var s in supplier_list_aes)
            {
                Console.WriteLine(s);
            }

            //4. Query and display the orders for a particular supplier. That is, if you type
            // in a S# or SN, your program displays a list of its corresponding PName  (part name)
            // and  Qty (quantity).

            Console.WriteLine("\n Please enter a S# or SN to display a supplier's part name and quantity. ");
            string sn = Console.ReadLine();
            int sNumber = int.Parse(sn);

            var supplier_info =
                from s in shipment
                join p in parts on s.PN equals p.PN
                where s.SN == sNumber
                select new { p.PName, s.Qty };

            foreach (var s in supplier_info)
            {
                Console.WriteLine(s);
            }

        }
        static void Main()
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
            }
        }
    }
}
