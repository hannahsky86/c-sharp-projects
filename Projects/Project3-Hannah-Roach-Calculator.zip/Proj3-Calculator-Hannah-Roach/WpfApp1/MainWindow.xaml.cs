﻿using System;
using System.Windows;
using System.Data;

namespace WpfApp1
{ 
    public partial class MainWindow : Window
    {

        private string string_formula = "";
    
        public MainWindow()
        {
            InitializeComponent();
        }
        
        /// <summary>
        /// This code is called when the "=" button is clicked. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bpound_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double result = Convert.ToDouble(new DataTable().Compute(string_formula, null));
                display.Text = string_formula + "=" + result.ToString();
                ClearReset();
            }
            catch (Exception ex)
            {
                display.Text = "ERROR";
                ClearReset();
            }
        }
        /// <summary>
        /// Clears settings after hitting the "C" button. 
        /// </summary>
        public void ClearReset()
        {
            string_formula = "";
            EnableButtons(false);
            bc.IsEnabled = true;
            Off.IsEnabled = true;
            On.IsEnabled = false;
        }

        /// <summary>
        /// C button actions.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bc_Click(object sender, RoutedEventArgs e)
        {
            string_formula = "";
            display.Text = "";
            EnableButtons(true);
        }

        /// <summary>
        /// This adds a character to the display and creates the formula;
        /// </summary>
        /// <param name="number"></param>
        private void CreateFormula(string number)
        {
            display.Text += number.ToString();
            string_formula += number;
        }

        /// <summary>
        /// Buttons methods. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b1_Click(object sender, RoutedEventArgs e) => CreateFormula("1");
        private void b2_Click(object sender, RoutedEventArgs e) => CreateFormula("2");
        private void b3_Click(object sender, RoutedEventArgs e) => CreateFormula("3");
        private void b4_Click(object sender, RoutedEventArgs e) => CreateFormula("4");
        private void b5_Click(object sender, RoutedEventArgs e) => CreateFormula("5");
        private void b6_Click(object sender, RoutedEventArgs e) => CreateFormula("6");
        private void b7_Click(object sender, RoutedEventArgs e) => CreateFormula("7");
        private void b8_Click(object sender, RoutedEventArgs e) => CreateFormula("8");
        private void b9_Click(object sender, RoutedEventArgs e) => CreateFormula("9");
        private void b0_Click(object sender, RoutedEventArgs e) => CreateFormula("0");
        private void plus_Click(object sender, RoutedEventArgs e) => CreateFormula("+");
        private void divide_Click(object sender, RoutedEventArgs e) => CreateFormula("/");
        private void times_Click(object sender, RoutedEventArgs e) => CreateFormula("*");
        private void minus_Click(object sender, RoutedEventArgs e) => CreateFormula("-");

        private void off_click(object sender, RoutedEventArgs e)
        {
            display.Text = "OFF";
            string_formula = "";
            TurnOn(false);
        }

        private void on_click(object sender, RoutedEventArgs e)
        {
            display.Text = "";
            TurnOn(true);
        }

        private void TurnOn(bool turn_on)
        {
            string_formula = "";
            EnableButtons(turn_on);
            Off.IsEnabled = turn_on;
            On.IsEnabled = !turn_on;
        }

        private void EnableButtons(bool is_on)
        {
            b0.IsEnabled = is_on;
            b1.IsEnabled = is_on;
            b2.IsEnabled = is_on;
            b3.IsEnabled = is_on;
            b4.IsEnabled = is_on;
            b5.IsEnabled = is_on;
            b6.IsEnabled = is_on;
            b7.IsEnabled = is_on;
            b8.IsEnabled = is_on;
            b9.IsEnabled = is_on;
            plus.IsEnabled = is_on;
            divide.IsEnabled = is_on;
            minus.IsEnabled = is_on;
            times.IsEnabled = is_on;
            bc.IsEnabled = is_on;
            bpound.IsEnabled = is_on;
        }
        /// <summary> Number 1 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void Button_Click1(object sender, RoutedEventArgs e)
        //{
        //    string number = "1";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 2 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b2_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "2";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 3 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b3_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "3";
        //    ReturnNumber(number);
        //}

        ///// <summary>  Number 4 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b4_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "4";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 5  </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b5_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "5";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 6 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b6_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "6";
        //    ReturnNumber(number);
        //}

        ///// <summary>  Number 7 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b7_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "7";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 8 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b8_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "8";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 9  </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b9_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "9";
        //    ReturnNumber(number);
        //}

        ///// <summary> Number 0 </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void b0_Click(object sender, RoutedEventArgs e)
        //{
        //    string number = "0";
        //    ReturnNumber(number);
        //}


    }
}

