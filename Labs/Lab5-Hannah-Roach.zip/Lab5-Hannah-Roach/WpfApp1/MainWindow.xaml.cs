﻿using System;
using System.Windows;

namespace WpfApp1
{

    public partial class MainWindow : Window
    {

        private string string_password = "";
        private string restricted_access =  "Restricted Access";
        private string access_denied = "Access Denied";
        

        enum Codes : int { T1 = 1645, T2 = 1689, C1 = 8345, S1 = 9998, S2 = 1006, S3 = 1007, S4 = 1008, }
        enum JobType { Technicians, Custodians, Scientists }

        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>  Code to check the pass code. </summary>
        /// <param name="number_password"></param>
        public void CheckPassCode(int number_password)
        {
            switch (number_password)
            {
                case (int)Codes.T1:
                    DisplayMessage(JobType.Technicians.ToString());
                    break;
                case (int)Codes.T2:
                    DisplayMessage(JobType.Technicians.ToString());
                    break;
                case (int)Codes.C1:
                    DisplayMessage(JobType.Custodians.ToString());
                    break;
                case (int)Codes.S1:
                    DisplayMessage(JobType.Scientists.ToString());
                    break;
                case (int)Codes.S2:
                    DisplayMessage(JobType.Scientists.ToString());
                    break;
                case (int)Codes.S3:
                    DisplayMessage(JobType.Scientists.ToString());
                    break;
                case (int)Codes.S4:
                    DisplayMessage(JobType.Scientists.ToString());
                    break;
                default:
                    DisplayMessage(access_denied);
                    break;
            }
        }
        
        /// <summary> This method calls the Add Char method and displays the hidden password </summary>
        /// <param name="number"></param>
        private void ReturnNumber(string number)
        {
            string_password += number;
            password_box.Password = string_password;
        }

        /// <summary> Displays message in Text box </summary>
        /// <param name="message"></param>
        private void DisplayMessage(string message)
        {
            results.Text += DateTime.Now + " ";
            results.Text += message;
            results.Text += "\n";
            string_password = "";
            password_box.Password = string_password;

        }

        /// <summary> This code calls the security guiard, if number is less than 10, and checks the passcode.  </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bpound_Click(object sender, RoutedEventArgs e)
        {
            int number_password = int.Parse(string_password);

            if (number_password < 10)
            {
                DisplayMessage(restricted_access);
            }
            else
            {
                CheckPassCode(number_password);
            }
        }

        /// <summary>  Button C.  </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bc_Click(object sender, RoutedEventArgs e)
        {
            password_box.Password = "";
            try
            {
                string_password = string_password.Substring(0, string_password.Length - 1);
                password_box.Password = string_password;
            }
            catch (Exception ex)
            {
                string_password = "";
                password_box.Password = string_password;
            }
        }

        /// <summary> Number 1 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            string number = "1";
            ReturnNumber(number);
        }

        /// <summary> Number 2 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b2_Click(object sender, RoutedEventArgs e)
        {
            string number = "2";
            ReturnNumber(number);
        }

        /// <summary> Number 3 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b3_Click(object sender, RoutedEventArgs e)
        {
            string number = "3";
            ReturnNumber(number);
        }

        /// <summary>  Number 4 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b4_Click(object sender, RoutedEventArgs e)
        {
            string number = "4";
            ReturnNumber(number);
        }

        /// <summary> Number 5  </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b5_Click(object sender, RoutedEventArgs e)
        {
            string number = "5";
            ReturnNumber(number);
        }

        /// <summary> Number 6 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b6_Click(object sender, RoutedEventArgs e)
        {
            string number = "6";
            ReturnNumber(number);
        }

        /// <summary>  Number 7 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b7_Click(object sender, RoutedEventArgs e)
        {
            string number = "7";
            ReturnNumber(number);
        }

        /// <summary> Number 8 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b8_Click(object sender, RoutedEventArgs e)
        {
            string number = "8";
            ReturnNumber(number);
        }

        /// <summary> Number 9  </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b9_Click(object sender, RoutedEventArgs e)
        {
            string number = "9";
            ReturnNumber(number);
        }

        /// <summary> Number 0 </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b0_Click(object sender, RoutedEventArgs e)
        {
            string number = "0";
            ReturnNumber(number);
        }
    }
}

