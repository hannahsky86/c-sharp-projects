﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Lab6_Hannah_Roach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int pkId = 0;
        string time_arrived;
        public int size_of_list = 0;

        private Dictionary<int, List<string>> package_address = new Dictionary<int, List<string>> { };
        private Dictionary<int, string> package_arrival = new Dictionary<int, string> { };
        private List<List<string>> data_table = new List<List<string>>();
        public List<String> NameCollection { get; set; }
        List<string> current_item = null;
        
        int number = 0;
        bool edited = false;

        public MainWindow()
        {
            InitializeComponent();
            DisablePackageFields(false);
            EnableAddressFields(false);
            DataContext = new ComboBoxViewModel();
        }

        /// <summary>
        /// Scan new item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Scan_New(object sender, RoutedEventArgs e)
        {
            pkId++;

            time_arrived = DateTime.Now.ToString();

            package_display.Text = time_arrived;
            arrived_at.Text = pkId.ToString();

            EnableAddressFields(true);
            SwichButtons(false);
        }

        /// <summary>
        /// Add and Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void additem_Click(object sender, RoutedEventArgs e)
        {
            if (edited)
            {
                SaveNewItem();
            }
            else
            {
                AddNewItem();
            }
        }

        public void SaveNewItem()
        {
            List<string> newList = new List<string>();
            current_item = data_table[number];
            newList = EditItemsInList(current_item);
            data_table[number] = newList;
            EnableAddressFields(false);
            SwitchButtons(true, size_of_list);
        }

        public void AddNewItem()
        {
            number++;
            string packageId = pkId.ToString();
            string time_arrived_string = time_arrived;
            string street = address_box.Text;
            string city = city_box.Text;
            string state = state_box.Text;
            string zip = zip_box.Text;

            List<string> allFields = new List<string>();
            allFields.Add(packageId);
            allFields.Add(time_arrived_string);
            allFields.Add(street);
            allFields.Add(city);
            allFields.Add(state);
            allFields.Add(zip);
            data_table.Add(allFields);

            EnableAddressFields(false);
            SwitchButtons(true, size_of_list);
            ResetTextFields();
        }

        /// <summary>
        /// Remove and item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void remove_button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                data_table.RemoveAt(number);
                EnableAddressFields(false);
                SwitchButtons(true, size_of_list);
                ResetTextFields();
                if (data_table.Count() == 0)
                {
                    pkId = 0;
                    number = 0;
                }
            }
            catch (Exception EX)
            {
            }
        }

        /// <summary>
        /// Edit the item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void edit_button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EnableAddressFields(true);
                additem.IsEnabled = true;
                edited = true;
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary>
        /// Edit Items in List 
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public List<string> EditItemsInList(List<string> item)
        {
            item[0] = package_display.Text;
            item[1] = arrived_at.Text;
            item[2] = address_box.Text;
            item[3] = city_box.Text;
            item[4] = state_box.Text;
            item[5] = zip_box.Text;
            return item;
        }

        /// <summary>
        /// Back button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            moveBack(data_table);
        }

        /// <summary>
        /// Move Back and item
        /// </summary>
        /// <param name="data_table"></param>
        public void moveBack(List<List<string>> data_table)
        {
            try
            {
                number--;
                current_item = data_table[number];
                UpdateFieldsWithNewInformation(current_item);
            }
            catch (Exception ex)
            {
                number++;
            }
        }

        /// <summary>
        /// Next button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void next_button_Click(object sender, RoutedEventArgs e)
        {
            moveNext(data_table);
        }
        
        /// <summary>
        /// Move to Next Item
        /// </summary>
        /// <param name="data_table"></param>
        public void moveNext(List<List<string>> data_table)
        {
            try
            {
                number++;
                current_item = data_table[number];
                UpdateFieldsWithNewInformation(current_item);
            }
            catch (Exception ex)
            {
                number--;
            }
        }

        /// <summary>
        /// Update fields with new information
        /// </summary>
        /// <param name="item"></param>
        private void UpdateFieldsWithNewInformation(List<string> item)
        {
            package_display.Text = item[0];
            arrived_at.Text = item[1];
            address_box.Text = item[2];
            city_box.Text = item[3];
            state_box.Text = item[4];
            zip_box.Text = item[5];
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string search_state = search_state_box.Text;
            listbox_for_ids.Items.Clear();
            foreach (var item in data_table)
            {
                if (item[4].Equals(search_state))
                {
                    listbox_for_ids.Items.Add(item[0]);
                }
            }
        }

        public int IncrementId(ref int pkId) => pkId++;

        //Scan or add item. Not both. 
        public void SwichButtons(bool isOn)
        {
            additem.IsEnabled = !isOn;
            scannew.IsEnabled = isOn;
        }
        public void SwitchButtons(bool isOn, int sizeOfList)
        {
            additem.IsEnabled = !isOn;
            scannew.IsEnabled = isOn;

            if (data_table.Count() > 0)
            {
                next_button.IsEnabled = isOn;
                back_button.IsEnabled = isOn;
                edit_button.IsEnabled = isOn;
                remove_button.IsEnabled = isOn;
            }
            else
            {
                next_button.IsEnabled = !isOn;
                back_button.IsEnabled = !isOn;
                edit_button.IsEnabled = !isOn;
                remove_button.IsEnabled = !isOn;
            }
        }

        //Disable packageId fields
        public void DisablePackageFields(bool isOpen)
        {
            arrived_at.IsEnabled = isOpen;
            package_display.IsEnabled = isOpen;
        }

        //Enable all address fiels
        public void EnableAddressFields(bool isOpen)
        {
            address_box.IsEnabled = isOpen;
            city_box.IsEnabled = isOpen;
            state_box.IsEnabled = isOpen;
            zip_box.IsEnabled = isOpen;
        }

        //all button except scan new are initially off
        public void InitializeButtons()
        {
            back_button.IsEnabled = false;
            additem.IsEnabled = false;
            remove_button.IsEnabled = false;
            edit_button.IsEnabled = false;
            next_button.IsEnabled = false;
        }

        //Clear text 
        public void ResetTextFields()
        {
            address_box.Text = "";
            city_box.Text = " ";
            state_box.Text = " ";
            zip_box.Text = " ";
            arrived_at.Text = " ";
            package_display.Text = " ";
        }
    }
}

