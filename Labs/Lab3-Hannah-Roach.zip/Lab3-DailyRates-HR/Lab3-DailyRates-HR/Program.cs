using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_DailyRates_HR
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }
        void run()
        {
            double fee = CalculateFee(600,2);
            Console.WriteLine($"The fee is {fee}");
        }
        private double CalculateFee(double rate = 375, int number_of_days = 5)
        {
            double total = rate * number_of_days;
            return total;
        }
        private double CalculateFee(double rate = 500)
        {
            int number_of_days = 1;
            double total = rate * number_of_days;
            return total;
        }
        private double CalculateFee()
        {
            int number_of_days = 1;
            double rate = 400.0;
            double total = rate * number_of_days;
            return total;
        }
    }
}
