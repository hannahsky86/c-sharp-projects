﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Lab4
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        double total_donation;
        double after_expense;

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void CalculateTotalAmtButton(object sender, RoutedEventArgs e)
        {
            try
            {
                double new_amount = double.Parse(donationAmt.Text);
                double total = CumulativeSum(ref new_amount);
                double after_deduction = total - total * 0.17;

                totalAmt.Text = $"(After Expense)\n ${after_deduction.ToString("#,##0.##")}";
                afterExpense.Text = $"(Total Raised)\n ${total.ToString("#,##0.##")}";
                donationAmt.Text = "";

            } catch (Exception)
            {
                donationAmt.Text = "";
            }
        }

        private double CumulativeSum(ref double totalDonation)
        {
            total_donation += totalDonation;
            return total_donation;
        }
    }
}
