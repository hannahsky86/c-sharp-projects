﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Midterm_Part2_Problem1_Hannah_Roach
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        int players_point = -1;
        Random rn = new Random();

        public MainPage()
        {
            this.InitializeComponent();
            point.Text = $"Point: ";
            outcome.Text = $"Outcome: ";
            rollButton.IsEnabled = false;
            playButton.IsEnabled = true;
        }

        private void Play(object sender, RoutedEventArgs e)
        {
            RollDice(sender,e, ref players_point);
        }

 
        public void Roll(object sender, RoutedEventArgs e)
        {
            
            RollDice(sender, e, ref players_point);
        }
        

        public void RollDice(object sender, RoutedEventArgs e, ref int players_point)
        {
            Random rnd1 = new Random();
            int dice1 = rn.Next(1, 8);
            int dice2 = rn.Next(1, 8);
            int sum = CalculateSum(dice1, dice2);

            if (sum == 7 || sum == 11 || players_point == sum)
            {
                ResultText.Text = "You win!!";
                outcome.Text = $"Outcome is {dice1}, {dice2}";
                if (players_point > 0)
                {
                    point.Text = $"Point: {players_point}";
                }
                else
                {
                    point.Text = $"Point: ";
                }
                playButton.IsEnabled = true;
                rollButton.IsEnabled = false;
            }
            else if (sum == 2 || sum == 3 || sum == 12)
            {
                ResultText.Text = "House  wins!";
                outcome.Text = $"Outcome is: {dice1}, {dice2}";
                if (players_point > 0)
                {
                    point.Text = $"Point: {players_point}";
                }
                else
                {
                    point.Text = $"Point: ";
                }
                playButton.IsEnabled = true;
                rollButton.IsEnabled = false;
            }
            else
            {
                players_point = sum;
                outcome.Text = $"Outcome is {dice1}, {dice2}";
                point.Text = $"Point: {players_point}";
                ResultText.Text = "Roll Again";
                playButton.IsEnabled = false;
                rollButton.IsEnabled = true;
            }
        }
        public void ResetFields(ref int players_point)
        {
            players_point = -1;
            point.Text = "";
            outcome.Text = "";
        }
        public int CalculateSum(int dice1,int dice2)
        {
            int sum = dice1 + dice2;
            return sum;
        }
       


    }
}
