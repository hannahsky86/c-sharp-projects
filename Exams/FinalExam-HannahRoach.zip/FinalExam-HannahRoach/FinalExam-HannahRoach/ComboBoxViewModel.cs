﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_HannahRoach
{
    class ComboBoxViewModel
    {
        
        public List<String> NameCollection { get; set; }

        public ComboBoxViewModel()
        {

            var parts = new[] {
             new {PN = 1, PName = "Nut", Color = "Red", Weight = 12, City = "London"},
            new {PN = 2, PName = "Bolt", Color = "Green", Weight = 17, City = "Paris"},
            new {PN = 3, PName = "Screw", Color = "Blue", Weight = 17, City = "Rome"},
            new {PN = 4, PName = "Screw", Color = "Red", Weight = 14, City = "London"},
            new {PN = 5, PName = "Cam", Color = "Blue", Weight = 12, City = "Paris"},
            new {PN = 6, PName = "Cog", Color = "Red", Weight = 19, City = "London"},
            };

            var pts = parts.Select(p => p.Color).Distinct();
            NameCollection = new List<string>() { };
            foreach (var p in pts)
            {
                NameCollection.Add(p); 
            }
        }
    }
}
