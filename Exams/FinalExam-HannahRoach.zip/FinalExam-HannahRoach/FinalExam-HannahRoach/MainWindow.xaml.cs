﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalExam_HannahRoach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<String> NameCollection = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            
            DataContext = new ComboBoxViewModel();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var parts = new[] {
             new {PN = 1, PName = "Nut", Color = "Red", Weight = 12, City = "London"},
            new {PN = 2, PName = "Bolt", Color = "Green", Weight = 17, City = "Paris"},
            new {PN = 3, PName = "Screw", Color = "Blue", Weight = 17, City = "Rome"},
            new {PN = 4, PName = "Screw", Color = "Red", Weight = 14, City = "London"},
            new {PN = 5, PName = "Cam", Color = "Blue", Weight = 12, City = "Paris"},
            new {PN = 6, PName = "Cog", Color = "Red", Weight = 19, City = "London"},
            };
            listbox_for_ids.Items.Clear();

            string item_selected = state_box.Text;

            var items = parts.Where(p => p.Color == item_selected).Select(p => p.PName);
            foreach (var i in items)
            {
                listbox_for_ids.Items.Add(i);
            }
        }
    }
}
