﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Midterm_Part2_Problem2_Hannah_Roach
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void calculateTotal_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
               
                int number_of_cartons = int.Parse(cartons.Text);
                int number_of_items = int.Parse(itemsPerCarton.Text);
                int total_items = number_of_cartons * number_of_items;
                if (total_items <=0)
                {
                    ResetFields();
                    note.Text = "Please enter whole numbers greater than 0.";  
                } else
                {
                    total.Text = total_items.ToString();
                    note.Text = "";
                }
            } catch(Exception ex)
            {
                ResetFields();
                note.Text = "Please enter values in the correct format.\n" +
                    "Only enter whole numbers greater than 0.";
            }
        }
        public void ResetFields()
        {
            total.Text = "";
            cartons.Text = "";
            itemsPerCarton.Text = "";
        }
    }
}
